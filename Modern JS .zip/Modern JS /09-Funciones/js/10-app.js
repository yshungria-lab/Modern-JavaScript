const aprendiendo = function() {
    console.log('Aprendiendo JavaScript');
}

const aprendiendo2 = () => 'Aprendiendo JavaScript';

console.log(aprendiendo2());