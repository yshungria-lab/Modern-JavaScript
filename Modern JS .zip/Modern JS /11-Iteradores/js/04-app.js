
let i = 100; // Inicializar el While

while(i < 10) { // Condición

    console.log(`Número ${i}`)


    i++; // Incremento
}