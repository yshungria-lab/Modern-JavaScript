
const puntaje = 1001;

if(puntaje == 1000) {
    console.log('si es igual...')
} 