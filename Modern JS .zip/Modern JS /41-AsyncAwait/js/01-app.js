
console.log(1 + 1);
try {
    autenticarUsuario();
} catch (error) {
    console.log(error);
}


console.log(2 + 2);