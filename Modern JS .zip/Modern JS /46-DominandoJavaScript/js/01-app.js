
const login = true;
const cliente = 'Juan';

function clienteLogueado() {
    
}

function funcion2() {
    console.log(cliente);
}

funcion2();
clienteLogueado();