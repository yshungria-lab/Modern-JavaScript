const producto = {
    nombre: "Monitor 20 Pulgadas",
    precio: 300,
    disponible: true
}

console.log( Object.keys( producto ) );


console.log( Object.values( producto ));


console.log(Object.entries(producto));