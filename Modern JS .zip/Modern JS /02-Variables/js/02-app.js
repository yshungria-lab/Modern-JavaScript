let producto = 'Tablet';

// Reasignar el valor

producto = "Monitor";

producto = 20;
producto = true;
producto = null


console.log(producto);


let precio;

precio = 300;

console.log(precio);