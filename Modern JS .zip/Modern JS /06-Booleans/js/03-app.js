const autenticado = true;

// if(autenticado) {
//     console.log('Si puedes ver netflix')
// } else {
//     console.log('No no puedes verlo')
// }


// Operador ternario

console.log( autenticado ? 'Si esta autenticado' : 'No esta autenticado');