const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio'];

meses[0] = 'Nuevo Mes';
meses[10] = 'Ultimo mes';

console.table(meses);