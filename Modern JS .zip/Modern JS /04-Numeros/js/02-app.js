const numero1 = 30;
const numero2 = 20;


let resultado;

// Suma
resultado = numero1 + numero2;

// Resta
resultado = numero1 - numero2;

// Multiplicación
resultado = numero1 * numero2;

// División
resultado = numero1 / numero2;

// Modulo
resultado = numero1 % numero2;

console.log(resultado);