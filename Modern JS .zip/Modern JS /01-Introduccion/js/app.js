console.log('Hola');
console.log('Mundo');


function hola() {
    console.log('Hola');
    console.log('Mundo');
    console.log('ok');
}


// eslint js/app.js encontrar errores de codigo
// eslint js/app.js --fix 